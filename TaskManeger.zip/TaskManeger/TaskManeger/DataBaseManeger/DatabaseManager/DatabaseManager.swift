//
//  DatabaseManager.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import Foundation
import Firebase
import FirebaseDatabase
import FirebaseAuth
class DatabaseManager{
    public static let shared = DatabaseManager()
    var isUser = true
    var currentRef :DatabaseReference!
    private let ref = Database.database().reference()
    
func signin(email:String,password:String,handler: @escaping (Bool,String?) -> Void){
// to sign in with firebase
    Auth.auth().signIn(withEmail: email, password: password){ authResult, error in
        
        
        guard let _ = authResult?.user, error == nil else {
           
           handler(false,error?.localizedDescription)
            
            
            
            return
            
        }
        
        
        let userRef = FirebaseConstant.userReferance.child((self.getUserUID()))
        print("njuserRefnj\(userRef)")
        userRef.observe(DataEventType.value, with: { (snapshot) in

            let value = snapshot.value as? NSDictionary
            var dic:[String:Any] = [:]
            dic["email"] = value?["email"] as? String ?? ""
            dic["udid"] = value?["udid"] as? String ?? ""
            dic["name"] = value?["name"] as? String ?? ""
            print("dicds\(dic)")



            UserHelper.saveUser(user:TUser(fromDictionary: dic))
        }
        )
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.3) {
            handler(true,"Login successfully")
        }
        
    }
}
    func getUserUID() -> String {
        
        if Auth.auth().currentUser?.uid != nil {
            let USERUID = Auth.auth().currentUser!.uid
            print("USERUID \(USERUID)")
            return USERUID
        }else{
            //user is not logged in
        }
        
        return ""
    }
func signUP(email:String,password:String,handler: @escaping (Bool,String?) -> Void){
    Auth.auth().createUser(withEmail: email, password:password) { (authRes, error) in
        if let error = error {
            print("mmkkkpo\(error)")
            handler(false,error.localizedDescription)
            return}
     
        guard let user = authRes?.user else { return }
        let udid = user.uid
        let dic :[String:Any] = ["udid":udid,
                                 "name":"",
                                 "email":email]
        FirebaseConstant.userReferance.child(udid).setValue(dic)
        
        handler(true,"successfully registered")

        
        
    }
    
}
    func addTask(titel:String,desc:String,startdate:String,enddate:String,handler: @escaping (Bool,String?) -> Void){
     
        let udid =  FirebaseConstant.ref.childByAutoId().key

        let dic :[String:Any] = ["udid":udid,
                                 "titel":titel,
                                 "descriptonString":desc,
                                 "startDate":startdate,
                                 "endDate":enddate
        
        ]
        FirebaseConstant.taskReferance.child("\(getUserUID())").child(udid ?? "").setValue(dic)
        
        handler(true,"successfull")
            
            
        }
    func editTask(id:String,titel:String,desc:String,startdate:String,enddate:String,handler: @escaping (Bool,String?) -> Void){
     

        
        var ref: DatabaseReference!
                    ref = Database.database().reference()
        let dic :[String:Any] = ["titel":titel,
                                 "descriptonString":desc,
                                 "startDate":startdate,
                                 "endDate":enddate
        
        ]
        FirebaseConstant.taskReferance.child("\(getUserUID())").child(id).updateChildValues(dic)
        
        
        handler(true,"Edit successfull")
            
            
        }


func getAllTask( complition : (([TTask])->Void)?) {
    var sections = [TTask]()
    let sectionRef = FirebaseConstant.taskReferance.child("\(getUserUID())")
    print("dfvmkldf\(sectionRef)")

    sectionRef.observe(DataEventType.value, with: { (snapshot) in
        let sectionDic =  snapshot.value as? [String : AnyObject] ?? [:]
        for (_, value) in sectionDic {
            if let value = value as? [String : AnyObject]  {
                let section = TTask.init(fromDictionary: value)
                
                sections.append(section)
                
                print("fvjilfil555\(sections.count)")
              

                
            }
            
        }
        complition?(sections)
        sections.removeAll()
        

    })
    
        
    }
    
    
   }
    func getTask(id:String,complition : ((TTask)->Void)?){
//
//        let sectionRef = FirebaseConstant.taskReferance.child("\(getUserUID())").child("ch741et")
//        print("dfvmkldf\(sectionRef)")
//        sectionRef.observe(DataEventType.value, with: { (snapshot) in
//            print("lnknjnjj\(snapshot.children)lll\(snapshot)")
//
//            let sectionDic =  snapshot.value as? [String : TTask] ?? [:]
//            print("lunknhvhvhvhvjnjj\(sectionDic[0].)")
//            complition?(sectionDic[0])
//
//        }
//        )
       
        }
        
        




//,complition : ((TTask)->Void)?)
