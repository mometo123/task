//
//  FirebaseConstant.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import Foundation
import Firebase
import FirebaseDatabase

class FirebaseConstant{
static var tokenNew = ""
static let  serverID = "AAAAE8rfoYs:APA91bFoVCybPtmgZB9hcyRcKGP30TBwEDjCvMK1ca3afmquii8wcqQxFAZtnDlZ90Ls-BTTetHKpRYFB-a3d4Om8IkO7uZz79V-2j5_sPSGrwOrxd11iEb7q38vgxk4us14s-mYzvmw"
    
    static var ref: DatabaseReference = Database.database().reference()
    static let userReferance =  ref.child("TUser")
    static let taskReferance =  ref.child("TTask")



}
