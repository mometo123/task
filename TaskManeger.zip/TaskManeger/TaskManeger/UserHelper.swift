//
//  UserHelper.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//
import Foundation
import UIKit

class UserHelper {
static var isUser =  true
    static func isLogin() -> Bool{
        return UserHelper.lodeUser() != nil
    }
    
    static func saveUser(user: TUser)  {
        
       let data = try! JSONEncoder().encode(user)
      
        let userdefult = UserDefaults.standard
        
        userdefult.set(data, forKey: "User")}
    static func lodeUser() -> TUser?{
        let userdefult = UserDefaults.standard
        guard let userData = userdefult.object(forKey: "User") as? Data else{
            return nil
        }
       
        let user = try! JSONDecoder().decode(TUser.self, from: userData)
        return user
    }
    
    
    static func deletUser(){
        let userdefult = UserDefaults.standard
        userdefult.removeObject(forKey: "User")
    }}
