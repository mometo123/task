//
//  helper.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import Foundation
class Helper {
    class func randomNameString(length: Int = 7)->String{
          
          enum s {
              static let c = Array("abcdefghjklmnpqrstuvwxyz12345789")
              static let k = UInt32(c.count)
          }
          
          var result = [Character](repeating: "-", count: length)
          
          for i in 0..<length {
              let r = Int(arc4random_uniform(s.k))
              result[i] = s.c[r]
          }
          
          return String(result)
      }
      }


