//
//  TTask.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import Foundation
class TTask : NSObject, NSCoding ,Codable{
    

    var titel : String!
    var descriptonString : String!
    var udid : String!
    var startDate : String!
    var endDate : String!

    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        titel = dictionary["titel"] as? String
        descriptonString = dictionary["descriptonString"] as? String
        udid = dictionary["udid"] as? String
        startDate = dictionary["startDate"] as? String
        endDate = dictionary["endDate"] as? String

    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if titel != nil{
            dictionary["titel"] = titel
        }
        if descriptonString != nil{
            dictionary["descriptonString"] = descriptonString
        }
        
       
        if udid != nil{
            dictionary["udid"] = udid
        }
        if startDate != nil{
            dictionary["startDate"] = udid
        }
        
        if endDate != nil{
            dictionary["endDate"] = udid
        }
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        titel = aDecoder.decodeObject(forKey: "titel") as? String
        descriptonString = aDecoder.decodeObject(forKey: "descriptonString") as? String
        udid = aDecoder.decodeObject(forKey: "udid") as? String
        startDate = aDecoder.decodeObject(forKey: "startDate") as? String
        endDate = aDecoder.decodeObject(forKey: "endDate") as? String

        
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if titel != nil{
            aCoder.encode(titel, forKey: "titel")
        }
        if descriptonString != nil{
            aCoder.encode(descriptonString, forKey: "sdescriptonStringame")
        }
        
        
        if udid != nil{
            aCoder.encode(udid, forKey: "udid")
        }
        if startDate != nil{
            aCoder.encode(udid, forKey: "startDate")
        }
        
        if endDate != nil{
            aCoder.encode(udid, forKey: "endDate")
        }
    }
}
