//
//  TUser.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import Foundation


class TUser : NSObject, NSCoding ,Codable{
    

    var email : String!
    var name : String!
    var udid : String!
   
    
    /**
     * Instantiate the instance using the passed dictionary values to set the properties values
     */
    init(fromDictionary dictionary: [String:Any]){
        email = dictionary["email"] as? String
        name = dictionary["name"] as? String
       
        udid = dictionary["udid"] as? String
        
    }
    
    /**
     * Returns all the available property values in the form of [String:Any] object where the key is the approperiate json key and the value is the value of the corresponding property
     */
    func toDictionary() -> [String:Any]
    {
        var dictionary = [String:Any]()
        if email != nil{
            dictionary["email"] = email
        }
        if name != nil{
            dictionary["name"] = name
        }
        
       
        if udid != nil{
            dictionary["udid"] = udid
        }
       
        return dictionary
    }
    
    /**
     * NSCoding required initializer.
     * Fills the data from the passed decoder
     */
    @objc required init(coder aDecoder: NSCoder)
    {
        email = aDecoder.decodeObject(forKey: "email") as? String
        name = aDecoder.decodeObject(forKey: "name") as? String
        udid = aDecoder.decodeObject(forKey: "udid") as? String
     
        
    }
    
    /**
     * NSCoding required method.
     * Encodes mode properties into the decoder
     */
    @objc func encode(with aCoder: NSCoder)
    {
        if email != nil{
            aCoder.encode(email, forKey: "email")
        }
        if name != nil{
            aCoder.encode(name, forKey: "sName")
        }
        
        
        if udid != nil{
            aCoder.encode(udid, forKey: "udid")
        }
        
    }
}
