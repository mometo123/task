//
//  TaskTVC.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit

class TaskTVC: UITableViewCell {

    @IBOutlet weak var viewcon: UIView!
    @IBOutlet weak var btnEdit: UIButton!
    @IBOutlet weak var descLbl: UILabel!
    @IBOutlet weak var end: UILabel!
    @IBOutlet weak var start: UILabel!
    @IBOutlet weak var titelLBl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        viewcon.layer.cornerRadius = 30
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
