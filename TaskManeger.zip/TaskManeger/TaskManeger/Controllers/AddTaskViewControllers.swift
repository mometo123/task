//
//  AddTaskViewControllers.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit
import IQKeyboardManagerSwift

protocol reload{
   func didReload()
        
    
}

class AddTaskViewControllers: UIViewController {
    var dataBaseMasnger = DatabaseManager()
   
    @IBOutlet weak var endDateTF: UITextField!
    @IBOutlet weak var detailTV: IQTextView!
    @IBOutlet weak var startDate: UITextField!
    @IBOutlet weak var titelTF: UITextField!
    
    var delegate:reload?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func btnAdd(_ sender: Any) {
        dataBaseMasnger.addTask(titel: self.titelTF.text ?? "", desc: self.detailTV.text ?? "", startdate: self.startDate.text ?? "", enddate: self.endDateTF.text ?? "") { status, message in
            
            if(status){
            let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                self.dismiss(animated: true)
                self.delegate?.didReload()
                self.navigationController?.popViewController(animated: true)




            }))


            self.present(alert, animated: true)
            }else{
                let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

                alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                    self.dismiss(animated: true)




                }))


                self.present(alert, animated: true)
            }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    }}

