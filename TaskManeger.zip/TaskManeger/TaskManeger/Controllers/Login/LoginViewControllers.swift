//
//  LoginViewControllers.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth

class LoginViewControllers: UIViewController {
    @IBOutlet weak var loginBtn: UIButton!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var viewPassword: UIView!
    @IBOutlet weak var viewEmail: UIView!
    var dataBaseMasnger = DatabaseManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        viewPassword.layer.cornerRadius = 20
        viewEmail.layer.cornerRadius = 20

        // Do any additional setup after loading the view.
    }
    
    @IBAction func signinBtn(_ sender: Any) {
       
        guard validationData() else {return}

        dataBaseMasnger.signin(email: self.emailTF.text!, password: self.passwordTF.text!) { status,message in
            if(status){
            let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                self.dismiss(animated: true)


                let vc = self.storyboard?.instantiateViewController(withIdentifier: "TasksViewController") as! TasksViewController
                
                self.navigationController?.pushViewController(vc, animated: true)



            }))


            self.present(alert, animated: true)
            }else{
                let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

                alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                    self.dismiss(animated: true)




                }))


                self.present(alert, animated: true)
            }
            
            
            
        }
        
        
    }
    
    @IBAction func btnSignUp(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension LoginViewControllers{
    func validationData() -> Bool{
        if emailTF.text!.isEmpty  {
            let alert = UIAlertController(title: "Empty Data", message: "You Must Enter Email", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                self.dismiss(animated: true)
                
            }))
            
            
            self.present(alert, animated: true)
            
            
            return false
        }
        
        if  passwordTF.text!.isEmpty{
            let alert = UIAlertController(title: "Empty Data", message: "You Must Enter Password", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                self.dismiss(animated: true)
                
            }))
            
            
            self.present(alert, animated: true)
            return false
        }
        return true
    }
}
extension LoginViewControllers:UITextFieldDelegate{
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if(textField == emailTF){
            self.passwordTF.becomeFirstResponder()

        }else{
            self.loginBtn.becomeFirstResponder()
        }
        
        
        
        return true
    }}
