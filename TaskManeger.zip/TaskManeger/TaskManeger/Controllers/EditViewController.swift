//
//  EditViewController.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit
import IQKeyboardManagerSwift
import FirebaseDatabase
import Firebase
import FirebaseAuth
protocol reloadd{
   func didReloadd()
        
    
}
class EditViewController: UIViewController {
    var dataBaseMasnger = DatabaseManager()

    @IBOutlet weak var endDate: UITextField!
    @IBOutlet weak var startDate: UITextField!
    @IBOutlet weak var titelLbl: UITextField!
    
    
    @IBOutlet weak var DetailsTV: IQTextView!
    var udid:String?
    var delegate:reloadd?
    override func viewDidLoad() {
        super.viewDidLoad()
        let restuarantRef =  FirebaseConstant.taskReferance.child("\(getUserUID())").child(udid ?? "")
        restuarantRef.observe(DataEventType.value, with: { (snapshot) in
                        let value = snapshot.value as? NSDictionary
                        self.titelLbl.text = value?["titel"] as? String ?? ""
                        self.startDate.text = value?["startDate"] as? String ?? ""
            self.endDate.text = value?["endDate"] as? String ?? ""
            self.DetailsTV.text = value?["descriptonString"] as? String ?? ""


        // Do any additional setup after loading the view.
        })}
 
                              
                              
    @IBAction func deleteTaskbtn(_ sender: Any) {
        var ref: DatabaseReference!
                    ref = Database.database().reference()
     
        
        FirebaseConstant.taskReferance.child("\(getUserUID())").child(udid ?? "").removeValue { error, _ in
            
            print(error)
        }
        self.delegate?.didReloadd()
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func btnSave(_ sender: Any) {
        dataBaseMasnger.editTask(id: udid ?? "", titel:self.titelLbl.text ?? "", desc: self.DetailsTV.text ?? "", startdate:  self.startDate.text ?? "", enddate: self.endDate.text ?? "") { status, message in
            if(status){
            let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                self.dismiss(animated: true)

                self.delegate?.didReloadd()
                self.navigationController?.popViewController(animated: true)



            }))


            self.present(alert, animated: true)
            }else{
                let alert = UIAlertController(title: "", message: message, preferredStyle: UIAlertController.Style.alert)

                alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                    self.dismiss(animated: true)




                }))


                self.present(alert, animated: true)
            }
        }
    }
    func getUserUID() -> String {
                                  
        if Auth.auth().currentUser?.uid != nil {
                                      let USERUID = Auth.auth().currentUser!.uid
                                      print("USERUID \(USERUID)")
                                      return USERUID
                                  }else{
                                      //user is not logged in
                                  }
                                  
                                  return ""
                              }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    }

