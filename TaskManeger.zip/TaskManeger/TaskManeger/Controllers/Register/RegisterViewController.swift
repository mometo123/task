//
//  RegisterViewController.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit

class RegisterViewController: UIViewController {
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var viewPassword: UIView!
    @IBOutlet weak var viewEmail: UIView!
    var dataBaseManger=DatabaseManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewPassword.layer.cornerRadius = 20
        viewEmail.layer.cornerRadius = 20
        // Do any additional setup after loading the view.
    }
    @IBAction func signUpBtn(_ sender: Any) {
        guard validationData() else {return}

        
        dataBaseManger.signUP(email: self.emailTF.text ?? "", password: self.passwordTF.text ?? "") { status,massege  in
            if (status){
            let alert = UIAlertController(title: "", message: massege, preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                self.dismiss(animated: true)
                self.navigationController?.popToRootViewController(animated: true)
                
            }))
            
            
            self.present(alert, animated: true)
            }
            else{
                let alert = UIAlertController(title: "", message: massege, preferredStyle: UIAlertController.Style.alert)
                
                alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                    
                    self.dismiss(animated: true)
                    
                }))
                
                
                self.present(alert, animated: true)
                
                
                
            }
            
            
            
        }
        
        
        
    }
   

}

extension RegisterViewController{
    func validationData() -> Bool{
        if emailTF.text!.isEmpty  {
            let alert = UIAlertController(title: "Empty Data", message: "You Must Enter Email", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                self.dismiss(animated: true)
                
            }))
            
            
            self.present(alert, animated: true)
            
            
            return false
        }
        
        if  passwordTF.text!.isEmpty{
            let alert = UIAlertController(title: "Empty Data", message: "You Must Enter Password", preferredStyle: UIAlertController.Style.alert)
            
            alert.addAction(UIAlertAction.init(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                self.dismiss(animated: true)
                
            }))
            
            
            self.present(alert, animated: true)
            return false
        }
        return true
    }
}


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


