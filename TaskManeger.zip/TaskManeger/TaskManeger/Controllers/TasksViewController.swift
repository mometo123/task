//
//  TasksViewController.swift
//  TaskManeger
//
//  Created by Walaa Khaled on 18/01/2023.
//

import UIKit

class TasksViewController: UIViewController ,reload,reloadd{
    func didReloadd() {
        self.tasks.removeAll()
        getTasks()
    }
    
    func didReload() {
        self.tasks.removeAll()
        getTasks()
        
    }
    
   
    
    @IBOutlet weak var blus: UIView!
    var tasks:[TTask]=[]
    var dataBaseMasnger = DatabaseManager()
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        initTableView()
        
        getTasks()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnAdd(_ sender: Any) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "AddTaskViewControllers") as! AddTaskViewControllers
        
        self.navigationController?.pushViewController(vc, animated: true)
        
        
    }
    func getTasks()
    {

        dataBaseMasnger.getAllTask { tasks in
            print("Fvdktasksnlf\(tasks.count)")
            self.tasks = tasks
            self.tableView.reloadData()
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension TasksViewController: UITableViewDataSource,UITableViewDelegate{
    func initTableView(){
        tableView.register(UINib(nibName: "TaskTVC", bundle: nil), forCellReuseIdentifier: "TaskTVC")
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tasks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TaskTVC", for: indexPath) as! TaskTVC
        cell.selectionStyle = .none
        var item = tasks[indexPath.row]
        cell.titelLBl.text = item.titel
        cell.descLbl.text = item.descriptonString
        cell.end.text = item.endDate
        cell.start.text = item.startDate
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        var item = tasks[indexPath.row]

        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "EditViewController") as! EditViewController
        vc.udid = item.udid
        
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}
